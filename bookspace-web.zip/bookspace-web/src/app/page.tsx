import Link from "next/link";

// Sementara. Diganti homepage lengkap di Tahap 3.
export default function Home() {
  return (
    <main className="mx-auto max-w-3xl p-8">
      <h1 className="font-display text-4xl font-extrabold text-navy">BOOKSPACE</h1>
      <p className="mt-3 text-mute">Fondasi proyek siap. Homepage dan katalog menyusul di Tahap 3.</p>
      <Link href="/status" className="mt-6 inline-block rounded-lg bg-navy px-4 py-2 font-bold text-white">
        Cek koneksi Supabase
      </Link>
    </main>
  );
}
