import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

// Halaman uji koneksi. Hapus sebelum rilis publik.
export default async function Status() {
  const env = {
    NEXT_PUBLIC_SUPABASE_URL: !!process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY: !!process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY,
    SUPABASE_SERVICE_ROLE_KEY: !!process.env.SUPABASE_SERVICE_ROLE_KEY,
    MIDTRANS_SERVER_KEY: !!process.env.MIDTRANS_SERVER_KEY,
  };

  let products: string, categories: string, session: string;
  try {
    const supabase = await createClient();
    const p = await supabase.from("products").select("*", { count: "exact", head: true });
    const c = await supabase.from("categories").select("*", { count: "exact", head: true });
    products = p.error ? `GAGAL: ${p.error.message}` : `${p.count} baris`;
    categories = c.error ? `GAGAL: ${c.error.message}` : `${c.count} baris`;
    const { data } = await supabase.auth.getClaims();
    session = data?.claims ? `login sebagai ${data.claims.email ?? data.claims.sub}` : "belum login";
  } catch (e) {
    products = categories = session = `GAGAL: ${(e as Error).message}`;
  }

  const rows: [string, string][] = [
    ...Object.entries(env).map(([k, v]): [string, string] => [k, v ? "terisi" : "KOSONG"]),
    ["Tabel products", products],
    ["Tabel categories", categories],
    ["Sesi", session],
  ];

  return (
    <main className="mx-auto max-w-2xl p-6">
      <h1 className="font-display text-3xl font-extrabold text-navy">Status koneksi</h1>
      <p className="mt-1 text-sm text-mute">Nilai kunci tidak pernah ditampilkan, hanya terisi atau kosong.</p>
      <dl className="mt-5 divide-y divide-line rounded-xl border border-line">
        {rows.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-4 p-3 text-sm">
            <dt className="font-medium">{k}</dt>
            <dd className={v.startsWith("GAGAL") || v === "KOSONG" ? "text-danger" : "text-mute"}>{v}</dd>
          </div>
        ))}
      </dl>
    </main>
  );
}
