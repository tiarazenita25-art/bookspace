import "server-only"; // build gagal jika file ini ter-import ke kode browser
import { createClient } from "@supabase/supabase-js";

// Klien dengan hak penuh (melewati RLS). HANYA untuk route server (Midtrans, admin).
export function createAdminClient() {
  return createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
