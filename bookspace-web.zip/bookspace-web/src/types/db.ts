export type Category = { id: number; name: string };

export type Product = {
  id: string;
  title: string;
  author: string | null;
  publisher: string | null;
  category_id: number | null;
  price: number;
  discount_pct: number;
  description: string | null;
  cover_url: string | null;
  stock: number;
  isbn: string | null;
  sold: number;
  rating_avg: number;
  review_count: number;
  created_at: string;
};

export type Profile = { id: string; full_name: string | null; phone: string | null; role: "customer" | "admin" };

export const finalPrice = (p: Pick<Product, "price" | "discount_pct">) =>
  Math.round((p.price * (100 - p.discount_pct)) / 100 / 500) * 500;

export const rupiah = (n: number) => "Rp" + n.toLocaleString("id-ID");
